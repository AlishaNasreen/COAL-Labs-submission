.model small
.stack 100h 
.data
.code
main proc 
    mov cx,26  ;condition
    mov dx,65 ;ascii of capital A
    
    AtoZ:  
    
    mov ah,2
    int 21h 
    
    inc dx  
    
    loop AtoZ  
    
    mov ah,4ch 
    int 21h 
    main endp
end main 