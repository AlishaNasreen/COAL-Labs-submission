.model small
.stack 100h
.code
main proc
    mov cx,4
    mov dx,48
    mov bl,0

PRINTDIGIT:
    mov ah,2
    int 21h
    mov al,dl
    sub al,48
    add bl,al
    inc dl
    loop PRINTDIGIT

    ; print new line
    mov ah,2
    mov dl,13
    int 21h
    mov dl,10
    int 21h

    ; print sum
    mov al,bl
    add al,48
    mov dl,al
    mov ah,2
    int 21h

    mov ah,4ch
    int 21h
main endp
end main
