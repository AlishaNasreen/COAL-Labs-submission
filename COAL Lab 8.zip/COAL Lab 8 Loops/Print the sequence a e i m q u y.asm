.model small
.stack 100h
.code
main proc     
    ;aeimquy print 
    mov cx,7       ; total 7 letters
    mov dx,97     ; start from 'a'

sequence:
    mov ah,2
    int 21h        

    add dx,4       
    loop  sequence
    
    mov ah,4ch
    int 21h
main endp
end main


