.model small
.stack 100h

.data
msg1 db 'enter my number (0-9): $'
msg2 db ,'my name is: $'
msg3 db ,'Alisha $'

.code
main proc
    mov ax, @data
    mov ds, ax              
    mov ah, 9               ;enter num
    mov dx, offset msg1
    int 21h    
    mov ah, 1                ;input
    int 21h                 
    sub al, 48             ; convert ASCII to number
    mov cx,0             
    mov cl, al
                 
    mov dx,10
    mov ah,2
    int 21h
    mov dx,13
    mov ah,2
    int 21h
    mov ah, 9                 ;dislay 2nd msg
    mov dx, offset msg2
    int 21h
    
    mov dx,10
    mov ah,2
    int 21h
    mov dx,13
    mov ah,2
    int 21h

print_loop:
    mov ah, 9
    mov dx, offset msg3
    int 21h
    
    mov dx,10
    mov ah,2
    int 21h
    mov dx,13
    mov ah,2
    int 21h                 

    loop print_loop         
    mov ah, 4Ch
    int 21h
main endp
end main
