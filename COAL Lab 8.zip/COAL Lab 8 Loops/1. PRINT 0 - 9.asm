.model small
.stack 100h
.data
.code
main proc
     mov cx,10  ;condition
     mov dx,48       ;0 asci code
     
     digit:
     mov ah,2
     int 21h            ;output
     inc dx              ;increement by 1
     loop digit          ; call
     
     mov ah,4ch 
     int 21h
     main endp
     