.model small
.stack 100h
.data
.code
main proc
    mov cx,26
    mov dx,97
    
    small:
    mov ah,2
    int 21h  
    
    inc dx  ;increment by 1
    loop small
     mov ah,4ch 
     int 21h
     main endp
end main