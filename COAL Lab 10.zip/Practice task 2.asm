; Program to print array elements using loop

.model small
.stack 100h
.data     
arr DB 49,50,51,52      ; ASCII codes for '1', '2', '3', '4'

.code
main proc
    
    mov ax, @data        ; Initialize data segment
    mov ds, ax  

    mov si, offset arr   ; SI points to first element of array
    mov cx, 4            ; Number of elements to print

loopx:
    mov dl, [si]         ; Load current array value into DL
    mov ah, 2            ; DOS print character function
    int 21h              ; Display character

    inc si               ; Move to next element
    loop loopx           ; Repeat until CX = 0

    mov ah, 4Ch          ; Exit program
    int 21h

main endp
end main