;program to calculate sum of first ten natural numbers without using counter 
org 100h 
include emu8086.inc 
 
.model small 
.stack 100h 
.data

msg1 db 'sum = $' 
.code 
main proc 
    mov bx, 0 
    mov ax, 0 

label1: 
add ax, bx
inc bx ;
 
cmp bx, 10 
Jle label1  

main endp  
 
call print_num 
DEFINE_PRINT_NUM ; used by print_num proc 
DEFINE_PRINT_NUM_UNS ; used by print_num proc end main 
ret

