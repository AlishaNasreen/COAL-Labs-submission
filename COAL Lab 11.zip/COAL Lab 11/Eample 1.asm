;program to swap two numbers 
.model small 
.stack 100h 
.data 
.code 
main proc 
mov ax,'1'  
; mov 1 to register ax 
push ax    
mov bx,'2' 
push bx 
pop ax 
pop bx
mov ah,4ch 
int 21h 
main endp 
end main