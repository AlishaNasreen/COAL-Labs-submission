 ; Task 2
 ;Write an assembly language program that input characters string and prints them in reverse order. Use a stack. 

  org 100h

 
.model small 
.data 
.code 
main proc 
     mov ax, 'A'
    Push ax
    
    mov ax,'L'
    Push ax
    
    mov ax, 'I'
    push ax
    
    mov ax,'S'
    push ax
    
    mov ax, 'H'
    push ax
    
      mov ax,'A'
      push ax
      
       
   mov cx,6
  stack_loop:
    pop dx             
    mov ah, 02h        
    int 21h
    loop stack_loop    
    
    
  
   
             

    mov ah, 4Ch
    int 21h
main endp
end main        
     
     
     
     
ret
