
;Task 1
;Write an assembly language program to push the following values on stack 450, 0, 487, 101, 500, 0, 359, 0, 458 
;Now write a code to delete the items having quantity zero and update the stack.

org 100h

.model small
.stack 100h
.data
.code
main proc
    mov ax, 4
    mov ax,30h
    Push ax
    
    mov ax,0
    add ax, 30h
    Push ax
    
    mov ax, 4
    add ax, 30h
    push ax
    
    mov ax,1
    add ax, 30h
    push ax
    
    mov ax, 5
    add ax, 30h
    push ax
    
      mov ax,0
      add ax, 30h
      push ax
      
       mov ax, 3
       add ax, 30h
      push ax
      
       mov ax, 0
       add ax, 30h
      push ax
      
       mov ax,4
       add ax, 30h
      push ax
        
        mov cx, 8
       
        
           

       stack_loop:
    pop dx
            cmp dl, '0'        
    je skip_print       
            
    mov ah, 02h
    int 21h   
      
          
    loop stack_loop  
    
       skip_print:
    loop stack_loop
    
      

    mov ah, 4Ch
    int 21h
main endp
end main        
ret