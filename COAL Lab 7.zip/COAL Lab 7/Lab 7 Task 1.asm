;Write an assembly language program that find the square of a number entered by user. Print the result on screen.

.model small
.stack 100h
.data
    msg1 db 'Enter a number (0-9): $'
    msg2 db 0Dh,0Ah, 'Square is: $'
    num db ?
    result db ?

.code
main proc
    mov ax, @data
    mov ds, ax

   
    mov ah, 9
    lea dx, msg1
    int 21h

        ;from user
    mov ah, 1
    int 21h
    sub al, 30h        ; Convert ASCII to number
    mov num, al

    ; Square the number: result = num * num
    mov al, num
    mov bl, num
    mul bl             
    
   
    mov result, al

    
    mov ah, 9
    lea dx, msg2
    int 21h

    
    mov al, result
    aam                ; Adjust for ASCII display (divide by 10)
    mov bx, ax
    add bh, 30h        ; Tens digit
    add bl, 30h        ; Ones digit
    mov dl, bh
    mov ah, 2
    int 21h
    mov dl, bl
    int 21h

    ; Exit program
    mov ah, 4Ch
    int 21h

main endp
end main
