.model small
.stack 100h
.data  
r db 'Remainder= $'
q db 'Quotient= $'


.code
main proc
         mov ax,27
         mov bl,5
         div bl
         mov cl,al
         mov ch,ah
         
         mov ax,@data
         mov ds,ax
         mov dx,offset q
         mov ah,9
         int 21h
         
         mov dl,cl
         add dl,48
         mov ah,2
         int 21h
         
         mov dx,10
         mov ah,2
         int 21h
         
         mov dx,13
         mov ah,2
         int 21h  
         
         mov ax,@data
         mov ds,ax
         mov dx,offset r
         mov ah,9
         int 21h    
         
         mov dl,ch
        add dl,48
         mov ah,2
         int 21h
         
         
    
         
         mov ah,4ch
         int 21h
         main endp
    
    
    
   end main
   