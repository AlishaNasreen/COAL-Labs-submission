;Write an assembly language program that find the cube of a number entered by user. Print the result on screen.

.model small  
.STACK 100H
.data  
    msg1 db 'Enter number (0-2): $'
    msg2 db 13,10,'Cube: $'

.code 
main proc
    mov ax, @data
    mov ds, ax

    ; Display prompt
    mov ah, 9
    mov dx, offset msg1
    int 21h

    ; Read input
    mov ah, 1
    int 21h

    ; Convert to number and calculate cube
    sub al, 30h ;ascii 
    mov bl, al
    mul bl
    mul bl

    ; Display result
    mov bl, al
    mov ah, 9
    mov dx, offset msg2
    int 21h

    mov dl, bl
    add dl, 30h
    mov ah, 2
    int 21h

    ; Exit
    mov ah, 4ch
    int 21h

main endp
end main
